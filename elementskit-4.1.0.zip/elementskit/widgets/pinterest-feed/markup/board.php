<div class="ekit-feed-pinterest-board">
    <div class="ekit-feed-pinterest-board--images">
        <div></div>
        <div class="span-3"></div>
        <div class="span-1"></div>
        <div></div>
    </div>
    <div class="ekit-feed-pinterest-board--info">
        <h4 class="ekit-feed-pinterest-board--name">
            <?php esc_html__('Web UI Design', 'elementskit')?>
        </h4>
        <p class="ekit-feed-pinterest-board--pins">
            <?php esc_html__('1375 Pins', 'elementskit')?>
        </p>
    </div>
</div>