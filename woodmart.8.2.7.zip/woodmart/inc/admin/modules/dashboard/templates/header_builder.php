<div id="whb-header-builder">
	<div class="xts-notice xts-info">
		<?php esc_attr_e( 'The header builder cannot be loaded correctly. Probably, there is some JS conflict with some of the installed plugins or some issue with the header builder script. Check your JS console to debug this. Try to disable all external plugins and be sure that you have the latest version of the theme installed and then check again.', 'woodmart' ); ?>
	</div>
</div>
