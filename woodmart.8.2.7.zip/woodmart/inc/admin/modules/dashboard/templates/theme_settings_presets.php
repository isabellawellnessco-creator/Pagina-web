<?php

XTS\Admin\Modules\Options\Presets::get_instance()->output_ui();
